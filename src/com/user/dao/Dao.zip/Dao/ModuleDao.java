package com.user.dao;

public class ModuleDao {
	public void AddModule(Module class1);
	public void modifyModule(Module class1);
	public void deleteModule(Module class1);
	public void searchModule(Module class1);
}
