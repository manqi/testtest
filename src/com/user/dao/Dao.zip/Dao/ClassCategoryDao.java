package com.user.dao;

public class ClassCategoryDao {
	public void AddClassCategory(ClassCategory class1);
	public void modifyClassCategory(ClassCategory class1);
	public void deleteClassCategory(ClassCategory class1);
	public void searchClassCategory(ClassCategory class1);

}
