package com.user.dao;

public class AllClassDao {
	public void AddAllClass(AllClass class1);
	public void modifyAllClass(AllClass class1);
	public void deleteAllClass(AllClass class1);
	public void searchAllClass(AllClass class1);

}
