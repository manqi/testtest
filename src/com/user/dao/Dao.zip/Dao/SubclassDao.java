package com.user.dao;

public class SubclassDao {
	public void AddSubclass(Subclass class1);
	public void modifySubclass(Subclass class1);
	public void deleteSubclass(Subclass class1);
	public void searchSubclass(Subclass class1);

}
