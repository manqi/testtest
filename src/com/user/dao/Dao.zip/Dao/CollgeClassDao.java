package com.user.dao;

public class CollgeClassDao {
	public void AddCollgeClass(CollgeClass class1);
	public void modifyCollgeClass(CollgeClass class1);
	public void deleteCollgeClass(CollgeClass class1);
	public void searchCollgeClass(CollgeClass class1);

}
