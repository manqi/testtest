package com.user.dao;

public class CorrespondingDao {
	public void addCorresponding();

}
